﻿function displayAlert() {


    Swal.fire(" Example with SweetAlert")

}