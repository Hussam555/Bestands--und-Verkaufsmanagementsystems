﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;

namespace Plugin.DataStore.SQL
{
    public class CategoryRepository : ICategoryRrpository
    {

        private readonly MarktContext _Dbcontext;

        public CategoryRepository(MarktContext dbcontext)
        {
            _Dbcontext = dbcontext;
        }

        public void AddCategory(Category category)
        {
            _Dbcontext.Add(category);
            _Dbcontext.SaveChanges();
        }

        public void DeleteCategory(int categoryId)
        {
            var Category = _Dbcontext.categories.Find(categoryId);

            if (Category == null) return;  

            _Dbcontext.Remove(Category);
            _Dbcontext.SaveChanges();
        }

        public void EditCategory(Category category)
        {
            var Category = _Dbcontext.categories.Find(category.CategoryId);
            Category.Name = category.Name;  
            Category.Description = category.Description;
            _Dbcontext.SaveChanges();


        }

        public IEnumerable<Category> GetCategories()
        {
           return _Dbcontext.categories.ToList();
        }

        public Category GetCategoryById(int categoryId)
        {
            return _Dbcontext.categories.Find(categoryId);
        }
    }
}
