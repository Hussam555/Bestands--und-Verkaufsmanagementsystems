﻿using CoreBusiness;
using Microsoft.EntityFrameworkCore;

namespace Plugin.DataStore.SQL
{
    public class MarktContext: DbContext
    {

        public MarktContext(DbContextOptions<MarktContext> dbContextOptions):base(dbContextOptions)
        {

        }
        public DbSet<Category> categories { get; set; }
        public DbSet<Product> products { get; set; }
        public DbSet<TransAction> transactions { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasMany(c => c.Products)
                .WithOne(p => p.Category).HasForeignKey(p => p.CategoryId);

            modelBuilder.Entity<Category>().HasData(

                new Category { CategoryId = 1, Name = "Beverage", Description = "Beverage" },
                new Category { CategoryId = 2, Name = "Bakery", Description = "Bakery" },
                new Category { CategoryId = 3, Name = "Meat", Description = "Meat" }


                );

            modelBuilder.Entity<Product>().HasData(

                new Product { ProductId = 1, CategoryId = 1, Name = "Iced Tea", Quantity = 100, Preis = 1.99 },
                new Product { ProductId = 2, CategoryId = 1, Name = "Canada Dry", Quantity = 200, Preis = 1.99 },
                new Product { ProductId = 3, CategoryId = 2, Name = "Whole Wheat bread", Quantity = 300, Preis = 1.50 },
                new Product { ProductId = 4, CategoryId = 2, Name = "White bread", Quantity = 300, Preis = 1.50 }

                );


        }


    }
}