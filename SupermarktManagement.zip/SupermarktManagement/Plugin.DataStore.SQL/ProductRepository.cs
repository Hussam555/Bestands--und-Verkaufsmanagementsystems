﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;

namespace Plugin.DataStore.SQL
{
    public class ProductRepository : IProductRrpository
    {
        private readonly MarktContext _DbContext;


        public ProductRepository(MarktContext dbContext)
        {
            _DbContext = dbContext;
        }

        public void AddProduct(Product product)
        {
            _DbContext.Add(product);
            _DbContext.SaveChanges();       
        }

        public void DeleteProduct(int productId)
        {
           var Product = _DbContext.products.Find(productId);

            if(Product ==null) return;
            _DbContext.products.Remove(Product);
            _DbContext.SaveChanges();
        }

        public void EditProduct(Product product)
        {
            var Product = _DbContext.products.Find(product.ProductId);
            Product.CategoryId = product.CategoryId;
            Product.Preis = product.Preis;
            Product.Name = product.Name;
            Product.Quantity = Product.Quantity;

            _DbContext.SaveChanges();
        }

        public Product GetProductById(int productId)
        {
            var product = _DbContext.products.Find(productId);
            return product;
        }

        public IEnumerable<Product> GetProducts()
        {
            return _DbContext.products.ToList();
        }

        public IEnumerable<Product> GetProductsByCategory(int categoryId)
        {
          return _DbContext.products.Where(x=>x.CategoryId == categoryId).ToList();
        }
    }
}
