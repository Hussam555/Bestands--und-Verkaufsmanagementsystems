﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;

namespace Plugin.DataStore.SQL
{
    public class TransactionRepository : ITransactionRepository
    {
        private readonly MarktContext _DbContext;

        public TransactionRepository(MarktContext dbContext)
        {
            _DbContext = dbContext;
        }

        public IEnumerable<TransAction> Get(string cashierName)
        {
            return _DbContext.transactions.ToList();
        }

        public IEnumerable<TransAction> GetByDay(string cashierName, DateTime dateTime)
        {
            if (string.IsNullOrWhiteSpace(cashierName))
                return _DbContext.transactions.Where(x => x.TimeStamp.Date == dateTime.Date);
            else
            {
                return _DbContext.transactions.Where(x => x.CashierName.ToLower() == cashierName.ToLower() &&
                 x.TimeStamp.Date == dateTime.Date
                );

            }
        }

        public void Save(string cashierName, int ProductId, double price, string productName, int beforQty, int soldqty)
        {
            var Transaction = new TransAction
            {
                ProductId = ProductId,
                ProductName = productName,  
                TimeStamp = DateTime.Now,
                Price = price,
                BeforeQty = beforQty,
                Soldqty = soldqty,
                CashierName = cashierName 
            };

            _DbContext.transactions.Add(Transaction);   
            _DbContext.SaveChanges();   
        }

        public IEnumerable<TransAction> Search(string cashierName, DateTime startDate, DateTime endDate)
        {
            if (string.IsNullOrWhiteSpace(cashierName))
                return _DbContext.transactions.Where(x => x.TimeStamp >= startDate.Date && x.TimeStamp <= endDate.Date.AddDays(1).Date);
            else
            {
                return _DbContext.transactions.Where(x => x.CashierName.ToLower() == cashierName.ToLower() &&
                 x.TimeStamp >= startDate.Date && x.TimeStamp <= endDate.Date.AddDays(1).Date
                );

            }
        }
    }
}
