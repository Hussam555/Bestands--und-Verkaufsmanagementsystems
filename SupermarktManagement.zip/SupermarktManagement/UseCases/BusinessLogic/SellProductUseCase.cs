﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;
using UseCases.IBusinessLogic;

namespace UseCases.BusinessLogic
{
    public class SellProductUseCase : ISellProductUseCase
    {

        private readonly IProductRrpository _productRrpository;
        private readonly IRecordTransactionUseCase recordTransactionUseCase;

        public SellProductUseCase(IProductRrpository productRrpository, IRecordTransactionUseCase recordTransactionUseCase)
        {
            _productRrpository = productRrpository;
            this.recordTransactionUseCase = recordTransactionUseCase;
        }

        public void Execute(string cashierName, int productId, int qtyToSell)
        {

            var product = _productRrpository.GetProductById(productId);
            if (product == null) return;

            product.Quantity -= qtyToSell;
            _productRrpository.EditProduct(product);
            recordTransactionUseCase.Exeute(cashierName, productId, qtyToSell);
        }


    }
}
