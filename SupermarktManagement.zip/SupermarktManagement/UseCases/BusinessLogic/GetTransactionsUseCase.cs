﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using CoreBusiness;
using UseCases.DataStorePluginInterfaces;
using UseCases.IBusinessLogic;

namespace UseCases.BusinessLogic
{
    public class GetTransactionsUseCase : IGetTransactionsUseCase
    {

        public readonly ITransactionRepository TransactionRepository;
        public GetTransactionsUseCase(ITransactionRepository transactionRepository)
        {
            TransactionRepository = transactionRepository;
        }


        public IEnumerable<TransAction> Execute(
            string cashierName,
            DateTime startDate,
            DateTime endDate
            )
        {
            return TransactionRepository.Search(cashierName, startDate, endDate);
        }

    }
}
