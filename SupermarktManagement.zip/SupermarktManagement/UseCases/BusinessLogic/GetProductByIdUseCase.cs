﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;
using UseCases.IBusinessLogic;

namespace UseCases
{
    public class GetProductByIdUseCase : IGetProductByIdUseCase
    {
        private readonly IProductRrpository _ProductRrpository;

        public GetProductByIdUseCase(IProductRrpository productRrpository)
        {
            this._ProductRrpository = productRrpository;
        }

        public Product Execute(int ProductId)
        {

            return _ProductRrpository.GetProductById(ProductId);

        }




    }
}
