﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;
using UseCases.IBusinessLogic;

namespace UseCases.BusinessLogic
{
    public class ViewProductByCategoryId : IViewProductByCategoryId
    {

        private readonly IProductRrpository productRrpository;

        public ViewProductByCategoryId(IProductRrpository productRrpository)
        {
            this.productRrpository = productRrpository;
        }

        public IEnumerable<Product> Execute(int categoryId)
        {

            return productRrpository.GetProductsByCategory(categoryId);
        }


    }
}
