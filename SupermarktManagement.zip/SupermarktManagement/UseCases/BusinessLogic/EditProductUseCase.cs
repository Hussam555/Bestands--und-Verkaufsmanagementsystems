﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;
using UseCases.IBusinessLogic;

namespace UseCases
{
    public class EditProductUseCase : IEditProductUseCase
    {

        private readonly IProductRrpository _productRrpository;

        public EditProductUseCase(IProductRrpository productRrpository)
        {
            _productRrpository = productRrpository;
        }

        public void Execute(Product product)
        {

            _productRrpository.EditProduct(product);

        }


    }
}
