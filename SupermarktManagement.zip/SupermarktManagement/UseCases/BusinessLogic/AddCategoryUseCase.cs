﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;
using UseCases.IBusinessLogic;

namespace UseCases.BusinessLogic
{
    public class AddCategoryUseCase : IAddCategoryUseCase
    {
        private readonly ICategoryRrpository categoryRrpository;

        public AddCategoryUseCase(ICategoryRrpository categoryRrpository)
        {
            this.categoryRrpository = categoryRrpository;
        }

        public void Execute(Category category)
        {

            categoryRrpository.AddCategory(category);

        }

    }
}
