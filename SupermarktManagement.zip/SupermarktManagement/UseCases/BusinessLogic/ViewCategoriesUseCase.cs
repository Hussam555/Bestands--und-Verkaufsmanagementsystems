﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;
using UseCases.IBusinessLogic;

namespace UseCases.BusinessLogic
{
    public class ViewCategoriesUseCase : IViewCategoriesUseCase
    {
        private readonly ICategoryRrpository categoryRrpository;

        public ViewCategoriesUseCase(ICategoryRrpository categoryRrpository)
        {
            this.categoryRrpository = categoryRrpository;
        }

        public IEnumerable<Category> Execute()
        {

            return categoryRrpository.GetCategories();
        }


    }
}
