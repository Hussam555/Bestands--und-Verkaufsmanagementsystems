﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;
using UseCases.IBusinessLogic;

namespace UseCases.BusinessLogic
{
    public class DeleteProductUseCase : IDeleteProductUseCase
    {

        private readonly IProductRrpository _productRrpository;

        public DeleteProductUseCase(IProductRrpository productRrpository)
        {
            _productRrpository = productRrpository;
        }

        public void Execute(int ProductId)
        {

            _productRrpository.DeleteProduct(ProductId);

        }


    }
}
