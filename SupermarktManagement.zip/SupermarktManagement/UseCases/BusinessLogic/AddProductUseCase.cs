﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;

namespace UseCases.BusinessLogic
{
    public class AddProductUseCase : IAddProductUseCase
    {

        private readonly IProductRrpository _productRrpository;

        public AddProductUseCase(IProductRrpository productRrpository)
        {
            _productRrpository = productRrpository;
        }

        public void Execute(Product product)
        {

            _productRrpository.AddProduct(product);

        }
    }
}
