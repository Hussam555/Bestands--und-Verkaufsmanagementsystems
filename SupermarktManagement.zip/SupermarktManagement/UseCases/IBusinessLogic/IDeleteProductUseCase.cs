﻿namespace UseCases.IBusinessLogic
{
    public interface IDeleteProductUseCase
    {
        void Execute(int ProductId);
    }
}