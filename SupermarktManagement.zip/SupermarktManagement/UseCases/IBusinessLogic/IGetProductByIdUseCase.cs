﻿using CoreBusiness;

namespace UseCases.IBusinessLogic
{
    public interface IGetProductByIdUseCase
    {
        Product Execute(int ProductId);
    }
}