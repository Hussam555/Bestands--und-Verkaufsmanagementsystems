﻿using CoreBusiness;

namespace UseCases.IBusinessLogic
{
    public interface IViewCategoriesUseCase
    {
        IEnumerable<Category> Execute();
    }
}