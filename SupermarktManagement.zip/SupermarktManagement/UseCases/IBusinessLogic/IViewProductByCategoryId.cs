﻿using CoreBusiness;

namespace UseCases.IBusinessLogic
{
    public interface IViewProductByCategoryId
    {
        IEnumerable<Product> Execute(int categoryId);
    }
}