﻿using CoreBusiness;

namespace UseCases.IBusinessLogic
{
    public interface IGetTransactionsUseCase
    {
        IEnumerable<TransAction> Execute(string cashierName, DateTime startDate, DateTime endDate);
    }
}