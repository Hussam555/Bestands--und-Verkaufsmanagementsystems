﻿namespace UseCases.IBusinessLogic
{
    public interface IDeleteCategoryUseCase
    {
        void Execute(int CategoryId);
    }
}