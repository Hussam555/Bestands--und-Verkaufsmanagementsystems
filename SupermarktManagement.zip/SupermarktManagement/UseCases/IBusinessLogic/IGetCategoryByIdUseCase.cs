﻿using CoreBusiness;

namespace UseCases.IBusinessLogic
{
    public interface IGetCategoryByIdUseCase
    {
        Category Execute(int categoryId);
    }
}