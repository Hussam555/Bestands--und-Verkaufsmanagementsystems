﻿using CoreBusiness;

namespace UseCases.IBusinessLogic
{
    public interface IGetTodayTransactionsUseCase
    {
        IEnumerable<TransAction> Execute(string cashierName);
    }
}