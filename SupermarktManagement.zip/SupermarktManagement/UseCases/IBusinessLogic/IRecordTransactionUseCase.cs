﻿namespace UseCases.IBusinessLogic
{
    public interface IRecordTransactionUseCase
    {
        void Exeute(string cashierName, int productId, int gty);
    }
}