﻿using CoreBusiness;

namespace UseCases.IBusinessLogic
{
    public interface IEditProductUseCase
    {
        void Execute(Product product);
    }
}