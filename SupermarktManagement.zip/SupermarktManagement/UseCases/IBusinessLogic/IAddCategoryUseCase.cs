﻿using CoreBusiness;

namespace UseCases.IBusinessLogic
{
    public interface IAddCategoryUseCase
    {
        void Execute(Category category);
    }
}