﻿using CoreBusiness;

namespace UseCases.IBusinessLogic
{
    public interface IEditCategoryUseCase
    {
        void Execute(Category category);
    }
}