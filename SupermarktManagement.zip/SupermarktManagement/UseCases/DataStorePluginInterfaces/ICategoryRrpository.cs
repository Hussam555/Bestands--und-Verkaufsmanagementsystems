﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UseCases.DataStorePluginInterfaces
{
    public interface ICategoryRrpository
    {

        public IEnumerable<Category> GetCategories();

        void AddCategory(Category category);
        void EditCategory(Category category);

        Category GetCategoryById(int categoryId);

        void DeleteCategory(int categoryId);
    }
}
