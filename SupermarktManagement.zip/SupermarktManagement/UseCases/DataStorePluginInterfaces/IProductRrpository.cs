﻿using CoreBusiness;

namespace UseCases.DataStorePluginInterfaces
{
     public interface IProductRrpository
    {

        public IEnumerable<Product> GetProducts();

        void AddProduct(Product product);

        void EditProduct(Product product);
        Product GetProductById(int productId);

        void DeleteProduct(int productId);

        IEnumerable<Product> GetProductsByCategory(int categoryId);


    }


}