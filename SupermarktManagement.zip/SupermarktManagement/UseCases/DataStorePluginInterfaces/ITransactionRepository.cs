﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace UseCases.DataStorePluginInterfaces
{

    public interface ITransactionRepository
    {
        public IEnumerable<TransAction> Get(string cashierName);
        public IEnumerable<TransAction> GetByDay(string cashierName, DateTime dateTime);
        public IEnumerable<TransAction> Search(string cashierName, DateTime startDate, DateTime dateTime);
        public void Save(string cashierName, int ProductId, double price, string productName, int beforQty, int soldqty);

    }


}
