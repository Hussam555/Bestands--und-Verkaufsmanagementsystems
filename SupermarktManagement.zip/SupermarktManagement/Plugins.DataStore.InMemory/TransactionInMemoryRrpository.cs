﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;

namespace Plugins.DataStore.InMemory
{
    public class TransactionInMemoryRrpository : ITransactionRepository
    {
        private List<TransAction> _transactions;

        public TransactionInMemoryRrpository()
        {
            _transactions = new List<TransAction>();
        }

        public IEnumerable<TransAction> Get(string cashierName)
        {
            if(string.IsNullOrWhiteSpace(cashierName))
                return _transactions;
            else
            {
                return _transactions.Where(x => string.Equals(x.CashierName, cashierName, StringComparison.OrdinalIgnoreCase));

            }

            
        }

        public IEnumerable<TransAction> GetByDay(string cashierName, DateTime dateTime)
        {
            if (string.IsNullOrWhiteSpace(cashierName))
                return _transactions.Where(x => x.TimeStamp.Date == dateTime.Date);
            else
            {
                return _transactions.Where(x => string.Equals(x.CashierName, cashierName, StringComparison.OrdinalIgnoreCase) &&
                 x.TimeStamp.Date == dateTime.Date
                );

            } 
        }



        public void Save(string cashierName, int ProductId, double price,string productName, int beforQty,int soldqty)
        {
            int tranactionId = 0;

            if (_transactions!= null && _transactions.Count>0)
            {
                int maxId = _transactions.Max(x => x.TransactionId);
                tranactionId = maxId + 1;   
            }
            else
            {

                tranactionId = 1;
            }

            _transactions.Add(new TransAction
            {
                TransactionId = tranactionId,
                ProductId = ProductId,
                ProductName = productName,
                TimeStamp= DateTime.Now,
                Price = price,  
                BeforeQty =beforQty,
                Soldqty = soldqty,
                CashierName = cashierName,
            });
        }

        public IEnumerable<TransAction> Search(string cashierName, DateTime startDate, DateTime endDate)
        {
            if (string.IsNullOrWhiteSpace(cashierName))
                return _transactions.Where(x => x.TimeStamp >= startDate.Date && x.TimeStamp <= endDate.Date.AddDays(1).Date);
            else
            {
                return _transactions.Where(x => string.Equals(x.CashierName, cashierName, StringComparison.OrdinalIgnoreCase) &&
                 x.TimeStamp >= startDate.Date && x.TimeStamp <= endDate.Date.AddDays(1).Date
                );

            }
        }

    }
}
