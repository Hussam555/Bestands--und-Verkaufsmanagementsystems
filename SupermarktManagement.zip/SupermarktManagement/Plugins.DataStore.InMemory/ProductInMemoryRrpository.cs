﻿using CoreBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UseCases.DataStorePluginInterfaces;

namespace Plugins.DataStore.InMemory
{
    public class ProductInMemoryRrpository : IProductRrpository
    {

        private List<Product> products;

        public ProductInMemoryRrpository()
        {

            products = new List<Product>()
            {

                new Product{ ProductId=1,CategoryId=1,Name="Iced Tea", Quantity=100, Preis=1.99},
                new Product{ ProductId=2,CategoryId=1,Name="Canada Dry", Quantity=200, Preis=1.99},
                new Product{ ProductId=3,CategoryId=2,Name="Whole Wheat bread", Quantity=300, Preis=1.50},
                new Product{ ProductId=4,CategoryId=2,Name="White bread", Quantity=300, Preis=1.50},


            };

        }

        public IEnumerable<Product> GetProducts()
        {
           return products; 
        }

        public void AddProduct(Product product)
        {
            if (products.Any(x => x.Name.Equals(product.Name, StringComparison.OrdinalIgnoreCase))) return;

            if (products != null && products.Count > 0)
            {

                var maxId = products.Max(x => x.ProductId);
                product.CategoryId = maxId + 1;

            }
            else
            {

                product.CategoryId = 1;
            }


            products.Add(product);
        }

        public void EditProduct(Product product)
        {
            var ProducttoEdit = GetProductById(product.ProductId);
            if (ProducttoEdit != null)
            {

                ProducttoEdit.Name = product.Name;
                ProducttoEdit.ProductId = product.ProductId;
                ProducttoEdit.Preis = product.ProductId;
                ProducttoEdit.Quantity = product.Quantity;
               
            }
        }


        public Product GetProductById(int ProductId)
        {

            return products.FirstOrDefault(x=>x.ProductId==ProductId);

        }


        public void DeleteProduct(int productId)
        {
            var ProductToDeletet = GetProductById(productId);
            products?.Remove(ProductToDeletet);
        }

        public IEnumerable<Product> GetProductsByCategory(int categoryId)
        {
            return products.Where(x=>x.CategoryId==categoryId);
        }
    }
}
